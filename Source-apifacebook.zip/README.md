# apifacebook
wt api 
comandos a ejecutar 
python callapi.py
